import requests

url = "https://www.sandbox.pitchup.com/rest/api/extraprice/"

payload = {
    "price": {
        "amount": None,
        "currency": ""
    },
    "day": None,
    "extra": None,
    "pricing_type": None,
    "date": None,
    "chargetype": None
}
headers = {
    "cookie": "puab=927d9213-f29b-42fb-8062-5e7b0bcf91e3; puab_variation=Control",
    "Content-Type": "application/json",
    "User-Agent": "insomnia/8.4.1",
    "Authorization": "Token d64c180b662d86793e0f883ae5eae5a920941a45"
}

response = requests.request("POST", url, json=payload, headers=headers)

print(response.text)
