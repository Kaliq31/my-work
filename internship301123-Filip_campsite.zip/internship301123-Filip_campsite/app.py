from flask import Flask,jsonify
import requests

url_1 = "https://www.sandbox.pitchup.com/rest/api/campsite/softcamp"

app = Flask(__name__)
@app.route("/campsite/")
def getowanie():
    payload = ""
    headers = {
        "cookie": "puab=927d9213-f29b-42fb-8062-5e7b0bcf91e3; puab_variation=Control",
        "Authorization": "Token d64c180b662d86793e0f883ae5eae5a920941a45",
        "User-Agent": "insomnia/8.4.0",
        "Cookie": "puab=927d9213-f29b-42fb-8062-5e7b0bcf91e3; puab_variation=Control"
    }

    response = requests.request("GET", url_1, data=payload, headers=headers)

    print(response.text)

    return jsonify({'camp': response.text})
